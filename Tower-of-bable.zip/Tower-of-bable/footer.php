<footer class="py-2 fixed-bottom" style="background: #484848;">

    <div class="container">
      <a class="navbar-brand" href="#">
        <img src="img/social-icon/vk.png" width="30" height="30" class="d-inline-block align-top" alt="">
      </a>
      <a class="navbar-brand" href="#">
        <img src="img/social-icon/instagram.png" width="30" height="30" class="d-inline-block align-top" alt="">
      </a>
      <a class="navbar-brand" href="#">
        <img src="img/social-icon/twitter.png" width="30" height="30" class="d-inline-block align-top" alt="">
      </a>
      <p class="d-inline-block float-right" style="color: #ccc;">Copyright &copy;</p>
    </div>

</footer>