<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Достижения</title>
	<?php
		include 'head.php';
	?>
</head>
<body>

<?php
	include 'header.php';
?>

<h1 style="text-align: center;">Достижения</h1>

<?php
	include 'footer.php';
?>

</body>
</html>