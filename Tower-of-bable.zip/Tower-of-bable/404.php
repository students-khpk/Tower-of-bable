<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>404 - Страница не найдена</title>
	<?php
		include 'head.php';
	?>
</head>
<body>

<h1 style="text-align: center;">Ошибка 404</h1>

</body>
</html>